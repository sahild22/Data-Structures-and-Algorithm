/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package breadthfirstsearch;

/**
 *
 * @author Sahil
 */
public class App {
    public static void main(String[] args){
        BreadthFirstSearch bfs = new BreadthFirstSearch();
        Vertex v1 = new Vertex(1);
        Vertex v2 = new Vertex(2);
        Vertex v3 = new Vertex(3);
        Vertex v4 = new Vertex(4);
        Vertex v5 = new Vertex(5);
        Vertex v6 = new Vertex(6);
        Vertex v7 = new Vertex(7);
        Vertex v8 = new Vertex(8);
        
        v1.addNeighbourVertex(v2);
        v1.addNeighbourVertex(v3);
        v1.addNeighbourVertex(v4);
        v2.addNeighbourVertex(v5);
        v2.addNeighbourVertex(v6);
        v3.addNeighbourVertex(v7);
        v6.addNeighbourVertex(v8);
        
        bfs.bfs(v1);
        
        
    }
}
